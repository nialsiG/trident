# trident
A library for dental microwear texture analysis, allowing to further analyze the results using a variety of methods. 
The package includes function to measure microwear texture, to transform the data, to rank variables, as well as a complete tcl/tk graphical user interface.
