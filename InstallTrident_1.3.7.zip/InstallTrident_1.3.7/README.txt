#TO INSTALL TRIDENT:
#1 Check that you have R > 4.0 and Rstudio installed

#2 Windows users: check that you have a matching version of RTools installed

#3 Open the "InstallTrident.Rproj"

#4 install all the dependencies:
install.packages(c("car", "DescTools", "doSNOW", "dplyr", "DT", "factoextra", "FactoMineR", "foreach", "ggpubr", "ggplot2", "MASS", "nortest", "parallel", "picante", "plyr", "shiny", "shinyjs", "shinyFiles", "snow", "stats", "stringr", "utils"))

#5 install the package from the tar.gz file in the project:
install.packages("trident_1.3.7.tar.gz", repos = NULL, type = "source")

#6 You can start using the app right away:
trident::trident.app()